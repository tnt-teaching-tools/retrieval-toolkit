Editable retrieval templates

Replace bracketed text with your own taught content.
Word: eight worksheets, individually and as one pack.
PowerPoint: fourteen editable activity slides, individually and as one pack.
PowerPoint speaker notes contain setup and checking guidance.
